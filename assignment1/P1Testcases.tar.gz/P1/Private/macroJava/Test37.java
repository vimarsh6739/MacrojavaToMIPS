class Test37{
    public static void main(String[] a){
	System.out.println(10 + 10);
    }
