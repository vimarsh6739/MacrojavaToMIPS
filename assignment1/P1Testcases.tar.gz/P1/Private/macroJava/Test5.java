class Test5{
    public static void main(String[] a){
	System.out.println(new TestClass().TestMethod());
    }
}
class TestClass{
    public int TestMethod(){
        if (10 + 10 <= 25)
            System.out.println(5 + 10);
        return 999 ;
    }
}
