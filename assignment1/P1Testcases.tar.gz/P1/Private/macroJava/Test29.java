#define TOPRINT(a) (a && a)
class Test29{
    public static void main(String[] a){
	System.out.println(TOPRINT( true));
    }
}
