#define Hundred() (10/)
class Test39{
    public static void main(String[] a){
	System.out.println(Hundred());
    }
}