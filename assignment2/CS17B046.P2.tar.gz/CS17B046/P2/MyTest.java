class MyTest
{
	public static void main(String [] args)
	{
		System.out.println(0);
	}
}

class A
{
	int f1;
	int f2;
	int f3;
	int[] f4;

	public int execute(C f1,int f2,int f3,int f4)
	{
		return 0;
	}
}
